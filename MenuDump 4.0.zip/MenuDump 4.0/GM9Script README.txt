#All credit for the gm9 script goes to TheCyberQuake

Just place this on your SD card in gm9/scripts/